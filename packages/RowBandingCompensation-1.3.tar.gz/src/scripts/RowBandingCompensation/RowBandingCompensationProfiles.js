function RowBandingCompensationBackgroundModel( parameters )
{
   this.parameters = parameters;
   this.cellSize = Math.max( 8, parameters.backgroundSamplingScale );
   this.gridWidth = 0;
   this.gridHeight = 0;
   this.gridValues = [];
   this.globalLevel = 0;
   this.cachedRowWidth = 0;
   this.cachedX0 = [];
   this.cachedX1 = [];
   this.cachedWx0 = [];
   this.cachedWx1 = [];

   this.build = function( image, exclusionImage )
   {
      this.gridWidth = Math.max( 2, Math.ceil( (image.width - 1) / this.cellSize ) + 1 );
      this.gridHeight = Math.max( 2, Math.ceil( (image.height - 1) / this.cellSize ) + 1 );

      var gridCount = this.gridWidth * this.gridHeight;
      var sums = new Array( gridCount );
      var counts = new Array( gridCount );
      for ( var i = 0; i < gridCount; ++i )
      {
         sums[ i ] = 0;
         counts[ i ] = 0;
      }

      var sampleStep = Math.max( 1, Math.round( this.cellSize / 4 ) );
      var sampleCount = 0;
      var sampleSum = 0;
      var sampleRows = Math.ceil( image.height / sampleStep );
      var progress = rbcCreateProgressReporter( "  Background sampling", sampleRows, 5 );
      var sampledRows = 0;
      var imageRow = rbcCreateRowBuffer( image.width );
      var maskRow = exclusionImage != null ? rbcCreateRowBuffer( image.width ) : null;

      for ( var y = 0; y < image.height; y += sampleStep )
      {
         rbcThrowIfAborted();
         imageRow = rbcReadRow( image, y, imageRow );
         if ( exclusionImage != null )
            maskRow = rbcReadRow( exclusionImage, y, maskRow );
         var gy = y / this.cellSize;
         var y0 = rbcClamp( Math.floor( gy ), 0, this.gridHeight - 1 );
         var y1 = Math.min( this.gridHeight - 1, y0 + 1 );
         var fy = y1 > y0 ? gy - y0 : 0;
         var wy0 = 1 - fy;
         var wy1 = fy;

         for ( var x = 0; x < image.width; x += sampleStep )
         {
            if ( maskRow != null && maskRow[ x ] >= 0.5 )
               continue;

            var gx = x / this.cellSize;
            var x0 = rbcClamp( Math.floor( gx ), 0, this.gridWidth - 1 );
            var x1 = Math.min( this.gridWidth - 1, x0 + 1 );
            var fx = x1 > x0 ? gx - x0 : 0;
            var wx0 = 1 - fx;
            var wx1 = fx;
            var sampleValue = imageRow[ x ];

            this.accumulateWeightedSample( sums, counts, x0, y0, wx0 * wy0, sampleValue );
            this.accumulateWeightedSample( sums, counts, x1, y0, wx1 * wy0, sampleValue );
            this.accumulateWeightedSample( sums, counts, x0, y1, wx0 * wy1, sampleValue );
            this.accumulateWeightedSample( sums, counts, x1, y1, wx1 * wy1, sampleValue );

            sampleSum += sampleValue;
            sampleCount += 1;
         }

         progress( ++sampledRows );
      }

      this.globalLevel = sampleCount > 0 ? sampleSum / sampleCount : image.median();
      this.gridValues = new Array( gridCount );
      for ( var j = 0; j < gridCount; ++j )
         this.gridValues[ j ] = counts[ j ] > 0 ? sums[ j ] / counts[ j ] : NaN;

      this.fillMissingCells();
      this.smoothGrid();
      this.ensureRowInterpolationCache( image.width );
   };

   this.accumulateWeightedSample = function( sums, counts, x, y, weight, value )
   {
      if ( weight <= 0 )
         return;
      var index = y * this.gridWidth + x;
      sums[ index ] += weight * value;
      counts[ index ] += weight;
   };

   this.fillMissingCells = function()
   {
      var unresolved = true;
      for ( var pass = 0; pass < this.gridWidth + this.gridHeight && unresolved; ++pass )
      {
         rbcThrowIfAborted();
         unresolved = false;
         var next = this.gridValues.slice( 0 );

         for ( var y = 0; y < this.gridHeight; ++y )
         {
            if ( (y & 15) == 0 )
               rbcThrowIfAborted();
            for ( var x = 0; x < this.gridWidth; ++x )
            {
               var index = y * this.gridWidth + x;
               if ( !isNaN( this.gridValues[ index ] ) )
                  continue;

               var sum = 0;
               var count = 0;
               for ( var dy = -1; dy <= 1; ++dy )
                  for ( var dx = -1; dx <= 1; ++dx )
                  {
                     if ( dx == 0 && dy == 0 )
                        continue;
                     var xx = x + dx;
                     var yy = y + dy;
                     if ( xx < 0 || yy < 0 || xx >= this.gridWidth || yy >= this.gridHeight )
                        continue;
                     var value = this.gridValues[ yy * this.gridWidth + xx ];
                     if ( !isNaN( value ) )
                     {
                        sum += value;
                        ++count;
                     }
                  }

               if ( count > 0 )
                  next[ index ] = sum / count;
               else
                  unresolved = true;
            }
         }

         this.gridValues = next;
      }

      for ( var i = 0; i < this.gridValues.length; ++i )
         if ( isNaN( this.gridValues[ i ] ) )
            this.gridValues[ i ] = this.globalLevel;
   };

   this.smoothGrid = function()
   {
      if ( this.gridValues.length == 0 || this.parameters.backgroundSmoothingStrength <= 0 )
         return;

      var sigma = Math.max( 0.75, this.parameters.backgroundSmoothingStrength );
      var radius = Math.max( 1, Math.ceil( 3 * sigma ) );
      var kernel = rbcCreateGaussianKernel1D( radius, sigma );
      var horizontallySmoothed = new Array( this.gridValues.length );

      for ( var y = 0; y < this.gridHeight; ++y )
      {
         if ( (y & 15) == 0 )
            rbcThrowIfAborted();
         var row = new Array( this.gridWidth );
         for ( var x = 0; x < this.gridWidth; ++x )
            row[ x ] = this.gridValues[ y * this.gridWidth + x ];

         row = rbcConvolve1D( row, kernel );
         for ( var xx = 0; xx < this.gridWidth; ++xx )
            horizontallySmoothed[ y * this.gridWidth + xx ] = row[ xx ];
      }

      var verticallySmoothed = new Array( this.gridValues.length );
      for ( var x0 = 0; x0 < this.gridWidth; ++x0 )
      {
         if ( (x0 & 15) == 0 )
            rbcThrowIfAborted();
         var column = new Array( this.gridHeight );
         for ( var y0 = 0; y0 < this.gridHeight; ++y0 )
            column[ y0 ] = horizontallySmoothed[ y0 * this.gridWidth + x0 ];

         column = rbcConvolve1D( column, kernel );
         for ( var yy = 0; yy < this.gridHeight; ++yy )
            verticallySmoothed[ yy * this.gridWidth + x0 ] = column[ yy ];
      }

      this.gridValues = verticallySmoothed;
   };

   this.ensureRowInterpolationCache = function( width )
   {
      width = Math.max( 0, Math.round( width ) );
      if ( this.cachedRowWidth == width )
         return;

      this.cachedRowWidth = width;
      this.cachedX0 = new Array( width );
      this.cachedX1 = new Array( width );
      this.cachedWx0 = new Array( width );
      this.cachedWx1 = new Array( width );

      for ( var x = 0; x < width; ++x )
      {
         var gx = rbcClamp( x / this.cellSize, 0, this.gridWidth - 1 );
         var x0 = Math.floor( gx );
         var x1 = Math.min( this.gridWidth - 1, x0 + 1 );
         var fx = x1 > x0 ? gx - x0 : 0;

         this.cachedX0[ x ] = x0;
         this.cachedX1[ x ] = x1;
         this.cachedWx0[ x ] = 1 - fx;
         this.cachedWx1[ x ] = fx;
      }
   };

   this.valueAt = function( x, y )
   {
      if ( this.gridValues.length == 0 )
         return 0;

      var gx = rbcClamp( x / this.cellSize, 0, this.gridWidth - 1 );
      var gy = rbcClamp( y / this.cellSize, 0, this.gridHeight - 1 );
      var x0 = Math.floor( gx );
      var y0 = Math.floor( gy );
      var x1 = Math.min( this.gridWidth - 1, x0 + 1 );
      var y1 = Math.min( this.gridHeight - 1, y0 + 1 );

      var fx = gx - x0;
      var fy = gy - y0;
      var v00 = this.gridValues[ y0 * this.gridWidth + x0 ];
      var v10 = this.gridValues[ y0 * this.gridWidth + x1 ];
      var v01 = this.gridValues[ y1 * this.gridWidth + x0 ];
      var v11 = this.gridValues[ y1 * this.gridWidth + x1 ];

      return (1 - fy) * ((1 - fx) * v00 + fx * v10) + fy * ((1 - fx) * v01 + fx * v11);
   };

   this.rowAt = function( y, width, row )
   {
      row = rbcEnsureRowBuffer( row, width );
      if ( this.gridValues.length == 0 )
      {
         for ( var z = 0; z < width; ++z )
            row[ z ] = 0;
         return row;
      }

      this.ensureRowInterpolationCache( width );

      var gy = rbcClamp( y / this.cellSize, 0, this.gridHeight - 1 );
      var y0 = Math.floor( gy );
      var y1 = Math.min( this.gridHeight - 1, y0 + 1 );
      var fy = y1 > y0 ? gy - y0 : 0;
      var wy0 = 1 - fy;
      var wy1 = fy;
      var rowOffset0 = y0 * this.gridWidth;
      var rowOffset1 = y1 * this.gridWidth;

      for ( var x = 0; x < width; ++x )
      {
         var x0 = this.cachedX0[ x ];
         var x1 = this.cachedX1[ x ];
         var wx0 = this.cachedWx0[ x ];
         var wx1 = this.cachedWx1[ x ];
         var top = this.gridValues[ rowOffset0 + x0 ] * wx0 + this.gridValues[ rowOffset0 + x1 ] * wx1;
         var bottom = this.gridValues[ rowOffset1 + x0 ] * wx0 + this.gridValues[ rowOffset1 + x1 ] * wx1;
         row[ x ] = top * wy0 + bottom * wy1;
      }
      return row;
   };

   rbcWrapProfiledMethod( this, "build", "BackgroundModel.build" );
   rbcWrapProfiledMethod( this, "fillMissingCells", "BackgroundModel.fillMissingCells" );
   rbcWrapProfiledMethod( this, "smoothGrid", "BackgroundModel.smoothGrid" );
    rbcWrapProfiledMethod( this, "ensureRowInterpolationCache", "BackgroundModel.ensureRowInterpolationCache" );
   rbcWrapProfiledMethod( this, "rowAt", "BackgroundModel.rowAt" );
}

function RowBandingCompensationProfileEstimator( parameters )
{
   this.parameters = parameters;

   this.estimate = function( image, exclusionImage, softBackgroundModel, rowInfluence )
   {
      var width = image.width;
      var height = image.height;
      var rowBackground = new Array( height );
      var validCounts = new Array( height );
      var directFlags = new Array( height );
      var interpolatedFlags = new Array( height );
      var anyFlags = new Array( height );

      var insufficientRows = 0;
      var rowProgress = rbcCreateProgressReporter( "  Row sampling", height, 5 );
      var imageRow = rbcCreateRowBuffer( width );
      var maskRow = exclusionImage != null ? rbcCreateRowBuffer( width ) : null;
      var backgroundRow = softBackgroundModel != null ? rbcCreateRowBuffer( width ) : null;

      for ( var y = 0; y < height; ++y )
      {
         rbcThrowIfAborted();
         imageRow = rbcReadRow( image, y, imageRow );
         if ( exclusionImage != null )
            maskRow = rbcReadRow( exclusionImage, y, maskRow );
         else
            maskRow = null;
         if ( softBackgroundModel != null )
            backgroundRow = softBackgroundModel.rowAt( y, width, backgroundRow );
         else
            backgroundRow = null;

         var validSamples = [];
         for ( var x = 0; x < width; ++x )
         {
            if ( maskRow != null && maskRow[ x ] >= 0.5 )
               continue;
            validSamples.push( imageRow[ x ] - (backgroundRow != null ? backgroundRow[ x ] : 0) );
         }

         validCounts[ y ] = validSamples.length;
         anyFlags[ y ] = validSamples.length > 0;
         directFlags[ y ] = validSamples.length >= this.parameters.minimumValidPixelsPerRow;
         interpolatedFlags[ y ] = false;

         if ( validSamples.length == 0 )
         {
            ++insufficientRows;
            rowBackground[ y ] = 0;
         }
         else
         {
            if ( !directFlags[ y ] )
               ++insufficientRows;
            rowBackground[ y ] = rbcEstimateRobustLocation(
               validSamples,
               this.parameters.rowEstimatorType,
               this.parameters.lowRejectQuantile,
               this.parameters.highRejectQuantile );
         }

         rowProgress( y + 1 );
      }

      if ( insufficientRows > 0 )
      {
         rowBackground = rbcInterpolateInvalidRows( rowBackground, anyFlags );
         for ( var i = 0; i < height; ++i )
            if ( !anyFlags[ i ] )
               interpolatedFlags[ i ] = true;
      }

      var rowTrend = this.parameters.enableRowTrendCorrection
         ? rbcSmooth1D( rowBackground, this.parameters.rowTrendSmoothingRadius )
         : rowBackground.slice( 0 );

      var rowResidual = new Array( height );
      for ( var j = 0; j < height; ++j )
         rowResidual[ j ] = this.parameters.enableRowTrendCorrection ? rowBackground[ j ] - rowTrend[ j ] : 0;

      var rowVisibility = this.parameters.enableRowVisibility
         ? this.computeVisibility( rowResidual )
         : this.zeroProfile( height );

      var rowConfidence = this.computeConfidence( width, validCounts, directFlags, interpolatedFlags, rowInfluence );
      var rowCorrection = this.computeCorrection( rowResidual, rowInfluence, rowVisibility, rowConfidence );

      return {
         rowBackground: rowBackground,
         rowTrend: rowTrend,
         rowResidual: rowResidual,
         rowVisibility: rowVisibility,
         rowConfidence: rowConfidence,
         rowCorrection: rowCorrection,
         validCounts: validCounts,
         directFlags: directFlags,
         interpolatedFlags: interpolatedFlags,
         insufficientRows: insufficientRows
      };
   };

   this.zeroProfile = function( length )
   {
      var zeros = new Array( length );
      for ( var i = 0; i < length; ++i )
         zeros[ i ] = 0;
      return zeros;
   };

   this.computeVisibility = function( rowResidual )
   {
      var visibility = new Array( rowResidual.length );
      var baseline;

      switch ( this.parameters.visibilityMode )
      {
      case "HighPassResidual":
         baseline = rbcSmooth1D( rowResidual, Math.max( 1, this.parameters.visibilitySmoothingRadius ) );
         for ( var i = 0; i < rowResidual.length; ++i )
            visibility[ i ] = Math.abs( rowResidual[ i ] - baseline[ i ] );
         break;

      case "FirstDerivative":
         for ( var j = 0; j < rowResidual.length; ++j )
         {
            var previous = rowResidual[ Math.max( 0, j - 1 ) ];
            var next = rowResidual[ Math.min( rowResidual.length - 1, j + 1 ) ];
            visibility[ j ] = Math.abs( next - previous ) * 0.5;
         }
         break;

      case "SecondDerivative":
         for ( var k = 0; k < rowResidual.length; ++k )
         {
            var a = rowResidual[ Math.max( 0, k - 1 ) ];
            var b = rowResidual[ k ];
            var c = rowResidual[ Math.min( rowResidual.length - 1, k + 1 ) ];
            visibility[ k ] = Math.abs( a - 2 * b + c );
         }
         break;

      default:
         var radius = Math.max( 1, this.parameters.visibilitySmoothingRadius );
         for ( var y = 0; y < rowResidual.length; ++y )
         {
            var window = [];
            for ( var yy = Math.max( 0, y - radius ); yy <= Math.min( rowResidual.length - 1, y + radius ); ++yy )
               window.push( rowResidual[ yy ] );
            var sorted = window.slice( 0 );
            sorted.sort( rbcNumericSort );
            var median = rbcMedianSorted( sorted );
            visibility[ y ] = Math.abs( rowResidual[ y ] - median ) / Math.max( 0.000001, rbcMad( window ) * 1.4826 );
         }
         break;
      }

      if ( this.parameters.visibilitySmoothingRadius > 0 )
         visibility = rbcSmooth1D( visibility, this.parameters.visibilitySmoothingRadius );
      return rbcNormalizeArray( visibility );
   };

   this.computeConfidence = function( width, validCounts, directFlags, interpolatedFlags, rowInfluence )
   {
      var confidence = new Array( validCounts.length );
      for ( var y = 0; y < validCounts.length; ++y )
      {
         if ( (y & 63) == 0 )
            rbcThrowIfAborted();
         var validFraction = validCounts[ y ] / Math.max( 1, width );
         var supportScore = Math.sqrt( validFraction );
         var confidenceValue = 0.15 + 0.85 * supportScore;

         if ( !directFlags[ y ] )
            confidenceValue *= 0.75;
         if ( interpolatedFlags[ y ] )
            confidenceValue *= 0.35;

         confidenceValue *= (1 - 0.20 * rowInfluence[ y ]);
         confidence[ y ] = rbcClamp( confidenceValue, 0, 1 );
      }
      return confidence;
   };

   this.computeCorrection = function( rowResidual, rowInfluence, rowVisibility, rowConfidence )
   {
      var correction = new Array( rowResidual.length );
      for ( var y = 0; y < rowResidual.length; ++y )
      {
         if ( (y & 63) == 0 )
            rbcThrowIfAborted();
         var value = rowResidual[ y ] * this.parameters.globalStrength;

         if ( this.parameters.enableStarInfluence )
            value *= 1 + this.parameters.localStarBoost * rowInfluence[ y ];

         if ( this.parameters.enableRowVisibility )
            value *= 1 + this.parameters.visibilityStrength * rowVisibility[ y ];

         if ( this.parameters.enableConfidenceWeighting )
            value *= Math.max( 0, 1 - this.parameters.confidenceStrength * (1 - rowConfidence[ y ]) );

         correction[ y ] = value;
      }

      if ( this.parameters.maximumPerIterationCorrection > 0 )
         correction = rbcClampAbsArray( correction, this.parameters.maximumPerIterationCorrection );
      return correction;
   };

   rbcWrapProfiledMethod( this, "estimate", "ProfileEstimator.estimate" );
   rbcWrapProfiledMethod( this, "zeroProfile", "ProfileEstimator.zeroProfile" );
   rbcWrapProfiledMethod( this, "computeVisibility", "ProfileEstimator.computeVisibility" );
   rbcWrapProfiledMethod( this, "computeConfidence", "ProfileEstimator.computeConfidence" );
   rbcWrapProfiledMethod( this, "computeCorrection", "ProfileEstimator.computeCorrection" );
}

function RowBandingCompensationCorrectionApplier( parameters )
{
   this.parameters = parameters;

   this.applyCorrectionToRow = function( row, correction )
   {
      for ( var x = 0; x < row.length; ++x )
         row[ x ] -= correction;
   };

   this.applyCorrectionToRowClampLow = function( row, correction )
   {
      for ( var x = 0; x < row.length; ++x )
         row[ x ] = Math.max( 0, row[ x ] - correction );
   };

   this.applyCorrectionToRowClamp01 = function( row, correction )
   {
      for ( var x = 0; x < row.length; ++x )
         row[ x ] = rbcClamp( row[ x ] - correction, 0, 1 );
   };

   this.applyCorrectionToRowWithProtection = function( row, correction, protectionRow, protectionStrength )
   {
      for ( var x = 0; x < row.length; ++x )
         row[ x ] -= correction * (1 - protectionStrength * rbcClamp( protectionRow[ x ], 0, 1 ));
   };

   this.applyCorrectionToRowWithProtectionClampLow = function( row, correction, protectionRow, protectionStrength )
   {
      for ( var x = 0; x < row.length; ++x )
         row[ x ] = Math.max( 0, row[ x ] - correction * (1 - protectionStrength * rbcClamp( protectionRow[ x ], 0, 1 )) );
   };

   this.applyCorrectionToRowWithProtectionClamp01 = function( row, correction, protectionRow, protectionStrength )
   {
      for ( var x = 0; x < row.length; ++x )
         row[ x ] = rbcClamp( row[ x ] - correction * (1 - protectionStrength * rbcClamp( protectionRow[ x ], 0, 1 )), 0, 1 );
   };

   this.apply = function( image, rowCorrection, protectionImage )
   {
      var progress = rbcCreateProgressReporter( "  Applying correction", image.height, 5 );
      var row = rbcCreateRowBuffer( image.width );
      var useProtection = this.parameters.enableProtectionMask && protectionImage != null;
      var protectionRow = useProtection ? rbcCreateRowBuffer( image.width ) : null;
      var clippingPolicy = this.parameters.clippingPolicy;
      var protectionStrength = this.parameters.protectionStrength;

      for ( var y = 0; y < image.height; ++y )
      {
         rbcThrowIfAborted();
         row = rbcReadRow( image, y, row );
         if ( useProtection )
            protectionRow = rbcReadRow( protectionImage, y, protectionRow );

         var correction = rowCorrection[ y ];
         if ( useProtection )
         {
            if ( clippingPolicy == "ClampLow" )
               this.applyCorrectionToRowWithProtectionClampLow( row, correction, protectionRow, protectionStrength );
            else if ( clippingPolicy == "Clamp01" )
               this.applyCorrectionToRowWithProtectionClamp01( row, correction, protectionRow, protectionStrength );
            else
               this.applyCorrectionToRowWithProtection( row, correction, protectionRow, protectionStrength );
         }
         else if ( clippingPolicy == "ClampLow" )
            this.applyCorrectionToRowClampLow( row, correction );
         else if ( clippingPolicy == "Clamp01" )
            this.applyCorrectionToRowClamp01( row, correction );
         else
            this.applyCorrectionToRow( row, correction );

         rbcWriteRow( image, y, row );
         progress( y + 1 );
      }
   };

   rbcWrapProfiledMethod( this, "applyCorrectionToRow", "CorrectionApplier.applyCorrectionToRow" );
   rbcWrapProfiledMethod( this, "applyCorrectionToRowClampLow", "CorrectionApplier.applyCorrectionToRowClampLow" );
   rbcWrapProfiledMethod( this, "applyCorrectionToRowClamp01", "CorrectionApplier.applyCorrectionToRowClamp01" );
   rbcWrapProfiledMethod( this, "applyCorrectionToRowWithProtection", "CorrectionApplier.applyCorrectionToRowWithProtection" );
   rbcWrapProfiledMethod( this, "applyCorrectionToRowWithProtectionClampLow", "CorrectionApplier.applyCorrectionToRowWithProtectionClampLow" );
   rbcWrapProfiledMethod( this, "applyCorrectionToRowWithProtectionClamp01", "CorrectionApplier.applyCorrectionToRowWithProtectionClamp01" );
   rbcWrapProfiledMethod( this, "apply", "CorrectionApplier.apply" );
}
